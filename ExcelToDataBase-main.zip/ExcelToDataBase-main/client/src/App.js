import ExcelToJson from './components/ExcelToJson';

function App() {
  return (
    <div className='App'>
      <ExcelToJson />
    </div>
  );
}

export default App;
