# ExcelToDataBase

React Page with a form to upload the excel sheet and that data will be imported to the Database

There is an excel sheet with 3 sheets-> User, Admin, Products.

Uploading the excel sheet will insert the data into respective tables(User, Admin, Products)


Add env file with fields:
NODE_ENV = development
PORT = 5000
MONGO_URI = your_mongodb_uri

Do npm install in main folder as well as client folder
And run "npm run dev"

